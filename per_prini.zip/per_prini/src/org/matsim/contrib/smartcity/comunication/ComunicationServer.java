/**
 * 
 */
package org.matsim.contrib.smartcity.comunication;

/**
 * Interface for server comunication
 * @author Filippo Muzzini
 *
 */
public interface ComunicationServer extends ComunicationEntity {

}
