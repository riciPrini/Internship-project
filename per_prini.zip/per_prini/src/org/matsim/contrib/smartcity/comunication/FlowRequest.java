/**
 * 
 */
package org.matsim.contrib.smartcity.comunication;

/**
 * @author Filippo Muzzini
 *
 */
public class FlowRequest extends ComunicationMessage {

	/**
	 * @param sender
	 */
	public FlowRequest(ComunicationClient sender) {
		super(sender);
	}

}
