/**
 * 
 */
package org.matsim.contrib.smartcity.agent;

/**
 * @author Filippo Muzzini
 *
 */
public interface AutonomousSpeed {

	public double getSpeed();
}
