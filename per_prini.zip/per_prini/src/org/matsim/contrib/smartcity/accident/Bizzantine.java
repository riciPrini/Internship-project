/**
 * 
 */
package org.matsim.contrib.smartcity.accident;

/**
 * Interface that means the agent can have a bizzantine behavior
 * @author Filippo Muzzini
 *
 */
public interface Bizzantine {

}
